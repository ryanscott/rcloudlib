@interface AppDelegate_Phone : NSObject <UIApplicationDelegate> 
{
	UIWindow *window;
}

@property (nonatomic, retain) UIWindow *window;

@end

