@interface AppDelegate_Pad : NSObject <UIApplicationDelegate> 
{
	UIWindow *window;
}

@property (nonatomic, retain) UIWindow *window;

@end

